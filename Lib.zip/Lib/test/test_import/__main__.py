import unittest

unittest.main('test.test_import')
